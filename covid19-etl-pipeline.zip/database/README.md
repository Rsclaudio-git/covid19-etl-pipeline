# 🗃️ PostgreSQL Database Scripts

This directory includes SQL scripts to:

- Create schemas: `STG`, `ODS`, `DWH`, `DTM`
- Create all required tables and sequences
- (Optional) Load initial sample data

Script: `create_schemas_and_tables.sql`